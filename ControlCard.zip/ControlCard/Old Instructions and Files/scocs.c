// program for Slow Control Of Calorimeter System ("scocs")
// not a very sophisticated program, so it does not need a very sophisticated name...
//
// G. Visser, Indiana University, 9/2013

#include <stdint.h>
#include <inttypes.h>
#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <time.h>    // for run 14 test log


const unsigned short OP_I2C_START     = 0x400;
const unsigned short OP_I2C_STOP      = 0x200;
const unsigned short OP_I2C_WRITE     = 0x100;
const unsigned short OP_I2C_READ_ACK  = 0x0ff;
const unsigned short OP_I2C_READ_NACK = 0x1ff;

struct linkusb_dev {
  int wr,rd;
};

#define BUFLEN  5000   // be careful it is enough! error checking not really implemented for this, I think
#define DBG_LEVEL 0 //2
#define IV_LOGFILE  "FPS_test_run14_SAVE.dat"

int linkusb_close(struct linkusb_dev *linkusb);
int linkusb_talk(struct linkusb_dev *linkusb, char *wbuf, int wlen, char *rbuf, int rlen);

int linkusb_open(struct linkusb_dev *linkusb, int unit) {
  char rbuf[BUFLEN];

  // should use unit argument to make the filename; for now just one unit supported
  if ((linkusb->wr=open("/dev/ttyUSB0",O_WRONLY|O_SYNC)) == -1) {
    printf("device write open error: %s\n",strerror(errno));
    return -1;
  }
  if ((linkusb->rd=open("/dev/ttyUSB0",O_RDONLY|O_NONBLOCK)) == -1) {
    printf("device read open error: %s\n",strerror(errno));
    close(linkusb->wr);
    return -1;
  }

/*   // this attempt to force a clean start doesn't really work quite right */
/*   linkusb_talk(linkusb,"\n\n",2,rbuf,-1);   // close byte mode (in case it was left hanging), or else this is just junk command and '?' response */
/*   printf("DBG: here on line 44\n"); */

  linkusb_talk(linkusb," ",1,rbuf,-1);    // check for connection & required firmware rev 1.6
  if ((strcmp(rbuf,"LinkUSB V1.7"))) {
    printf("ERROR: LinkUSB ID check failed, got %s\n",rbuf);
    linkusb_close(linkusb);
    return -1;
  }
  linkusb_talk(linkusb,"\"r",2,rbuf,-1);  // set "iso" mode and issue the dummy 1-wire reset that seems necessary
  linkusb_talk(linkusb,"r",1,rbuf,-1);    // another 1-wire reset & expect a good response now
  if (strcmp(rbuf,"P"))
    printf("WARNING: On linkusb_open, got unexpected 1-wire reset response: %s\n",rbuf);

  return 0;
}

int linkusb_close(struct linkusb_dev *linkusb) {
  close(linkusb->wr);
  close(linkusb->rd);
  return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////
// write to LinkUSB device and possibly read response
// call with rlen > 0 to expect some fixed length response
//           rlen < 0 to expect a variable-length, newline-terminated response
//                      (newline will be stripped here, any data after it may be lost)
//           rlen = 0 to expect no response
// the response will be put in rbuf, null-terminated
// for fixed length rbuf must be >rlen+1 chars, for variable length BUFLEN chars
///////////////////////////////////////////////////////////////////////////////////////////
int linkusb_talk(struct linkusb_dev *linkusb, char *wbuf, int wlen, char *rbuf, int rlen) {
  int n,j=0,k,timeout=0;
  char *end;

  write(linkusb->wr,wbuf,wlen);  // add error check of course
  if (rlen==0)
    return 0;
  n  = (rlen>0 ? rlen : BUFLEN-1);
  while (1) {
    //printf("iter %d\n",timeout);
    // do something better here?  (select, poll, or epoll functions may be used?)
    // https://banu.com/blog/2/how-to-use-epoll-a-complete-example-in-c/
    usleep(30000); // this delay is experimentally tuned to be about right to get ~20 chars in one iteration
    if (timeout++==66) {  // 33 should be enough for AD5694 writes. maybe reads.
      printf("read timeout\n");
      break;
    }
    if ((k=read(linkusb->rd,rbuf+j,n-j)) > 0) {
      j += k;
      //printf("got %d, total %d\n",k,j);
      int m;
      for(m=0;m<k;m++)
	//printf("  at %d %d %c\n",m,rbuf[j-k+m],rbuf[j-k+m]);
	if ((rlen<0)&&((end=strstr(rbuf,"\r\n"))!=NULL)) { // got newline on a variable read
	  //printf("got newline, at %d\n",end-rbuf);
	  *end = 0;
	  return 0;
	}
	else if ((rlen>0)&&(j==n)) {
	  //printf("got exact\n");
	  rbuf[j] = 0;
	  return 0;
	}
    }
    else if ((k<0)&&(errno!=EAGAIN)) {
      printf("read error: %s\n",strerror(errno));
      break;
    }
  }
  rbuf[0]=0;
  return -1;
}

int DS2413_post(char *wbuf, int data) {

  data = 0xfc | (data & 0x03);           // upper bits to 1 (see DS2413 datasheet)
  return sprintf(wbuf,"%02X%02XFFFF",    // send the byte & its complement, and 2 read frames (again see datasheet on this)
		 data,(~data)&0xff);
}

///////////////////////////////////////////////////////////////////////////////////////////
// write/read I2C device through DS2413 through LinkUSB
// i2cwbuf/i2crbuf format/usage similar to future FPS control FPGA implementation of
//   I2C through DS2413 through FPGA 1-wire master
///////////////////////////////////////////////////////////////////////////////////////////
int DS2413_talk_I2C(struct linkusb_dev *linkusb, uint64_t owaddr,
		    unsigned int *i2cwbuf, int length, unsigned int *i2crbuf) {
  int i,j,k,tmp;
  char wbuf[BUFLEN],*pwbuf=wbuf,rbuf[BUFLEN],*prbuf=rbuf;

  linkusb_talk(linkusb,"r",1,rbuf,-1);  // 1-wire reset, expect "P" response
  //printf("reset: got %d chars:\n%s\n",strlen(rbuf),rbuf);
  if (strcmp(rbuf,"P")) {
    printf("ERROR: 1-wire reset response: %s\n",rbuf);
    return -1;
  }

  pwbuf+=sprintf(pwbuf,"b55");                      // set LinkUSB byte mode and send match rom command
  for(k=0;k<8;k++)                              // send the address
    pwbuf+=sprintf(pwbuf,"%02X",(uint32_t) (owaddr>>8*k)&0xff);  // Note: UPPERCASE hexadecimal REQUIRED for all linkusb input!!
  pwbuf+=sprintf(pwbuf,"5A");                        // pio write command

  for(i=0;i<length;i++) {
    if (i2cwbuf[i]==OP_I2C_START) {
      // FORCE an extra stop condition here, this is needed only because program might have been killed while talking, do not do this in final FPS HW configuration
      pwbuf+=DS2413_post(pwbuf,0x1);     // take SCL high to prepare for stop condition
      pwbuf+=DS2413_post(pwbuf,0x3);     // stop (SDA goes high while SCL high)
      // start condition
      pwbuf+=DS2413_post(pwbuf,0x1);     // start condition (SDA goes low while SCL (still, from before) high)
      pwbuf+=DS2413_post(pwbuf,0x0);     // SDA and SCL low, prepare for data phase
    }
    else if (i2cwbuf[i]==OP_I2C_STOP) {
      pwbuf+=DS2413_post(pwbuf,0x1);     // take SCL high to prepare for stop condition
      pwbuf+=DS2413_post(pwbuf,0x3);     // stop (SDA goes high while SCL high)
    }
    else { // data read/write
      for(j=7;j>=0;j--) {
	pwbuf += DS2413_post(pwbuf,tmp = ((i2cwbuf[i]>>j)&0x1)<<1);   // set SDA to the data bit j
	pwbuf += DS2413_post(pwbuf, tmp|0x1);                         // SCL high, hold SDA
	pwbuf += DS2413_post(pwbuf, tmp);                             // SCL low, hold SDA
      }
      pwbuf += DS2413_post(pwbuf,tmp = ((i2cwbuf[i]>>8)&0x1)<<1);   // set SDA to the ack bit write flag
      pwbuf += DS2413_post(pwbuf, tmp|0x1);                         // SCL high, hold SDA
      pwbuf += DS2413_post(pwbuf, tmp);                             // SCL low, hold SDA
    }
  }
  pwbuf += sprintf(pwbuf,"\n");                        // close LinkUSB byte mode

#if (DBG_LEVEL>=3)
  printf("Will send (%d chars):\n%s",strlen(wbuf),wbuf);
#endif
  linkusb_talk(linkusb,wbuf,strlen(wbuf),rbuf,-1);
#if (DBG_LEVEL>=3)
  printf("bytemode: got %d chars:\n%s\n",strlen(rbuf),rbuf);
#endif

  prbuf+=20;   // skip to after the write mode command (0x5A)
  int m=0;
  for(i=0;i<length;i++) {
    if (i2cwbuf[i]==OP_I2C_START) {
      prbuf+=32;                         // skip 4 [why 4? SEE ABOVE!]  (we don't check start cond, for now anyway)
    }
    else if (i2cwbuf[i]==OP_I2C_STOP) {
      prbuf+=16;                         // skip 2 (we don't check stop cond, for now anyway)
    }
    else { // data read/write
      i2crbuf[m]=0;
      for(j=7;j>=0;j--) {
	prbuf+=8;
	prbuf+=7;
	i2crbuf[m] |= ( (*prbuf&0x4)!=0 ? 1<<j : 0 );
	prbuf+=1;
	prbuf+=8;
      }
      prbuf+=8;
      prbuf+=7;
      i2crbuf[m] |= ( (*prbuf&0x4)!=0 ? 1<<8 : 0 );
      prbuf+=1;
      prbuf+=8;
      m++;
    }
  }
#if (DBG_LEVEL>=3)
  printf("used to %d\n",prbuf-rbuf);
#endif
  return 0;
}

///////////////////////////////////////////////////////////////////////////////////////////
// set an AD5694 DAC channel through DS2413 through LinkUSB
// this function stays exactly same for final FPS control system
///////////////////////////////////////////////////////////////////////////////////////////
int AD5694_write_dac(struct linkusb_dev *linkusb, uint64_t owaddr, int i2caddr, int chan, int data) {
  unsigned int i2cwbuf[12],i2crbuf[12];    // this is _just_ enough - be careful if changing code below!
  // BUT IF INCREASING CHECK BUFLEN VALUE!!!!
  int k=0,j;

  i2cwbuf[k++] = OP_I2C_START;         // start condition
  i2cwbuf[k++] = OP_I2C_WRITE | ((i2caddr&0x7f)<<1);  // I2C write flag bit is 0
  i2cwbuf[k++] = OP_I2C_WRITE | 0x30 | (0x1<<(chan&0x3));  // AD5694 command byte (write and update, ignore LDAC pin)
  i2cwbuf[k++] = OP_I2C_WRITE | ((data>>4)&0xff);     // upper 8 data bits
  i2cwbuf[k++] = OP_I2C_WRITE | ((data<<4)&0xff);     // lower 4 data bits
  i2cwbuf[k++] = OP_I2C_STOP;         // stop condition

#if (DBG_LEVEL>=2)
  printf("i2cwbuf");
  for(j=0;j<k;j++)
    printf("[%d]: %04x  ",j,i2cwbuf[j]);
  printf("\n");
#endif
  DS2413_talk_I2C(linkusb,owaddr,i2cwbuf,k,i2crbuf);
#if (DBG_LEVEL>=2)
  printf("i2crbuf");
  for(j=0;j<k-2;j++)
    printf("[%d]: %04x  ",j,i2crbuf[j]);
  printf("\n");
#endif
  for(j=0;j<k-2;j++) {
    if (i2crbuf[j]&0x100)
      printf("NAK on I2C write (i2crbuf[%d]: %04x)\n",j,i2crbuf[j]);
  }
  return 0;
}

int ADS7823_convert_read(struct linkusb_dev *linkusb, uint64_t owaddr, int i2caddr, unsigned int *adc) {
  unsigned int i2cwbuf[12],i2crbuf[12];    // this is _just_ enough - be careful if changing code below!
  // BUT IF INCREASING CHECK BUFLEN VALUE!!!!
  int k=0,j;

  // do a conversion
  i2cwbuf[k++] = OP_I2C_START;         // start condition
  i2cwbuf[k++] = OP_I2C_WRITE | ((i2caddr&0x7f)<<1);  // I2C write flag bit is 0
  i2cwbuf[k++] = OP_I2C_WRITE | 0x00;  // ADS7823 convert command byte
  i2cwbuf[k++] = OP_I2C_STOP;         // stop condition

#if (DBG_LEVEL>=2)
  printf("i2cwbuf");
  for(j=0;j<k;j++)
    printf("[%d]: %04x  ",j,i2cwbuf[j]);
  printf("\n");
#endif
  DS2413_talk_I2C(linkusb,owaddr,i2cwbuf,k,i2crbuf);
#if (DBG_LEVEL>=2)
  printf("i2crbuf");
  for(j=0;j<k-2;j++)
    printf("[%d]: %04x  ",j,i2crbuf[j]);
  printf("\n");
#endif
  for(j=0;j<k-2;j++) {
    if (i2crbuf[j]&0x100)
      printf("NAK on I2C write (i2crbuf[%d]: %04x)\n",j,i2crbuf[j]);
  }

  // get the data
  k=0;
  i2cwbuf[k++] = OP_I2C_START;         // start condition
  i2cwbuf[k++] = OP_I2C_WRITE | ((i2caddr&0x7f)<<1) | 0x01;  // I2C write flag bit is 1
  i2cwbuf[k++] = OP_I2C_READ_ACK;
  i2cwbuf[k++] = OP_I2C_READ_NACK;     // nack the 2nd read byte, is normal termination
  i2cwbuf[k++] = OP_I2C_STOP;         // stop condition

#if (DBG_LEVEL>=2)
  printf("i2cwbuf");
  for(j=0;j<k;j++)
    printf("[%d]: %04x  ",j,i2cwbuf[j]);
  printf("\n");
#endif
  DS2413_talk_I2C(linkusb,owaddr,i2cwbuf,k,i2crbuf);
#if (DBG_LEVEL>=2)
  printf("i2crbuf");
  for(j=0;j<k-2;j++)
    printf("[%d]: %04x  ",j,i2crbuf[j]);
  printf("\n");
#endif
  if (i2crbuf[0]&0x100)
    printf("NAK on I2C write (i2crbuf[%d]: %04x)\n",j,i2crbuf[j]);
  *adc = ((i2crbuf[1]&0x0f)<<8)|(i2crbuf[2]&0xff);
  return 0;
}

int ADS7828_convert_read(struct linkusb_dev *linkusb, uint64_t owaddr, int i2caddr, int chan, unsigned int *adc) {
  unsigned int i2cwbuf[12],i2crbuf[12];    // this is _just_ enough - be careful if changing code below!
  // BUT IF INCREASING CHECK BUFLEN VALUE!!!!
  int k=0,j;

  // do a conversion
  chan = ((chan & 0x7)%2)*4+(chan & 0x7)/2; // remap channel index - see the ADS7828 datasheet, we use SE mode
  i2cwbuf[k++] = OP_I2C_START;         // start condition
  i2cwbuf[k++] = OP_I2C_WRITE | ((i2caddr&0x7f)<<1);  // I2C write flag bit is 0
  i2cwbuf[k++] = OP_I2C_WRITE | 0x80 | (chan<<4);     // ADS7828 convert command byte, SE, external reference mode!
  i2cwbuf[k++] = OP_I2C_STOP;         // stop condition

#if (DBG_LEVEL>=2)
  printf("i2cwbuf");
  for(j=0;j<k;j++)
    printf("[%d]: %04x  ",j,i2cwbuf[j]);
  printf("\n");
#endif
  DS2413_talk_I2C(linkusb,owaddr,i2cwbuf,k,i2crbuf);
#if (DBG_LEVEL>=2)
  printf("i2crbuf");
  for(j=0;j<k-2;j++)
    printf("[%d]: %04x  ",j,i2crbuf[j]);
  printf("\n");
#endif
  for(j=0;j<k-2;j++) {
    if (i2crbuf[j]&0x100)
      printf("NAK on I2C write (i2crbuf[%d]: %04x)\n",j,i2crbuf[j]);
  }

  // get the data
  //GV: 8/27/14 -- am I checking all the response as much as possible for ACK's from the target device??
  // I'm not completely sure. This comment prompted by work on changing one-wire pullup voltage to see effects of that,
  //   of course it gives errors at extremes.
  k=0;
  i2cwbuf[k++] = OP_I2C_START;         // start condition
  i2cwbuf[k++] = OP_I2C_WRITE | ((i2caddr&0x7f)<<1) | 0x01;  // I2C write flag bit is 1
  i2cwbuf[k++] = OP_I2C_READ_ACK;
  i2cwbuf[k++] = OP_I2C_READ_NACK;     // nack the 2nd read byte, is normal termination
  i2cwbuf[k++] = OP_I2C_STOP;         // stop condition

#if (DBG_LEVEL>=2)
  printf("i2cwbuf");
  for(j=0;j<k;j++)
    printf("[%d]: %04x  ",j,i2cwbuf[j]);
  printf("\n");
#endif
  DS2413_talk_I2C(linkusb,owaddr,i2cwbuf,k,i2crbuf);
#if (DBG_LEVEL>=2)
  printf("i2crbuf");
  for(j=0;j<k-2;j++)
    printf("[%d]: %04x  ",j,i2crbuf[j]);
  printf("\n");
#endif
  if (i2crbuf[0]&0x100)
    printf("NAK on I2C write (i2crbuf[%d]: %04x)\n",j,i2crbuf[j]);
  *adc = ((i2crbuf[1]&0x0f)<<8)|(i2crbuf[2]&0xff);
  return 0;
}

// This function will modfiy the voltage and comp parameters to the actual set values. These will normally be only slightly
// different but in case of out of range request will be substantially different.
int set_voltage(struct linkusb_dev *linkusb, uint64_t owaddr, int chan, double vcal, double *voltage, double *comp) {
  int setdac,compdac;
  const int chan2dac[4]={1,0,2,3};
  double voltage_request,comp_request;

    printf("requested  chan %d, voltage %.4lf (at 25 deg C), compensation slope %.5lf\n",
	   chan,*voltage,*comp);

    // rescale the requested voltage according to measured calibration
    voltage_request=(*voltage)*68.000/vcal;
    comp_request=(*comp)*68.000/vcal;

    compdac = (int) (4096*comp_request/0.0725+0.5);
    if (compdac<0) {
      printf("compensation slope cannot be negative, setting to 0\n");
      compdac = 0;
    }
    else if (compdac>4095) {
      printf("requested compensation slope too large, setting to maximum\n");
      compdac = 4095;
    }

    setdac = (int) (4096*(voltage_request-51.89-12.14625*((double) compdac)/4096)/16.56 + 0.5);
    if (setdac<0) {
      printf("requested voltage too low (at this compensation value), setting to minimum\n");
      setdac = 0;
    }
    else if (setdac>4095) {
      printf("requested voltage too high (at this compensation value), setting to maximum\n");
      setdac = 4095;
    }
    // report back actual set values
    *voltage=(51.89+12.14625*((double) compdac)/4096+(((double) setdac)/4096)*16.56)*vcal/68.0000;  // use actual scale factor for this board
//OUCH -- IS THIS RIGHT (next line) ???
    *comp=0.0725*((double) compdac)/4096*vcal/68.0000;
    printf("actual set chan %d, voltage %.4lf (at 25 deg C), compensation slope %.5lf",
	   chan,*voltage,*comp);
    printf("  [by dac channel %d setdac=%d, compdac=%d]\n",chan2dac[chan],setdac,compdac);

    AD5694_write_dac(linkusb,owaddr,0x0c,chan2dac[chan],setdac);
    AD5694_write_dac(linkusb,owaddr,0x0d,chan2dac[chan],compdac);
    return 0;
}

// temperature from compensated reference voltage on UCLA-HCAL FEE board (not for hacked FPS board!)
int get_temperature(struct linkusb_dev *linkusb, uint64_t owaddr, double *temperature) {
  unsigned int adc;

  ADS7823_convert_read(linkusb,owaddr,0x48,&adc);
  *temperature = 32.5 + (((double) adc)*2.500/4096 - 1.762)/0.01094;
  return 0;
}

int prototype_get_current(struct linkusb_dev *linkusb, uint64_t owaddr, double *current) {
  unsigned int adc;

  ADS7823_convert_read(linkusb,owaddr,0x48,&adc);
  *current = ((((double) adc)+0.5)*2.500/4096)/0.2;  // current in microamperes = voltage / 0.2 Megohm   ; for the sake of logscale plots report from middle of bin
  return 0;
}

int main(int argc, char *argv[])
{
  extern char *optarg;
  int c;
  uint64_t owaddr;
  int do_dac=0,do_FPS_test_IV=0,do_standard=0,do_standby=0,do_Iread=0;
  struct linkusb_dev linkusb;
  int chan,bdserial,bdhalf;
  double voltage,comp,current,vreq,voltage_b,comp_b;
  FILE *logfile;
  const uint64_t owaddr_table[45][2]={
    {0x900000001743AD3AULL,0x520000001726283AULL},   // HCAL serial #0001 section 1 & 2
    {0x660000001732523AULL,0xAB0000001743C63AULL},   // HCAL serial #0002 section 1 & 2
    {0xB80000001736213AULL,0x730000001743E43AULL},   // HCAL serial #0003 section 1 & 2
    {0x3D00000017335B3AULL,0xCF0000001736723AULL},   // HCAL serial #0004 section 1 & 2
    {0x0F0000001736843AULL,0x680000001820F33AULL},   // HCAL serial #0005 section 1 & 2
    {0xE10000001839C63AULL,0x5D0000001820E13AULL},   // HCAL serial #0006 section 1 & 2
    {0x770000001839CF3AULL,0xB60000001820E43AULL},   // HCAL serial #0007 section 1 & 2
    {0xDC00000017367C3AULL,0xBD00000017260B3AULL},   // HCAL serial #0008 section 1 & 2
    {0x650000001726293AULL,0x0D00000017261E3AULL},   // HCAL serial #0009 section 1 & 2
    {0x2700000017387F3AULL,0x180000001736AC3AULL},   // HCAL serial #0010 section 1 & 2
    {0x5700000017542D3AULL,0x370000001736793AULL},   // HCAL serial #0011 section 1 & 2
    {0xCB0000001736543AULL,0xC90000001736473AULL},   // HCAL serial #0012 section 1 & 2
    {0xA90000001743D53AULL,0x8E0000001736A53AULL},   // HCAL serial #0013 section 1 & 2
    {0xD40000001839D43AULL,0x310000001820F03AULL},   // HCAL serial #0014 section 1 & 2
    {0x3A00000017261F3AULL,0x640000001732413AULL},   // HCAL serial #0015 section 1 & 2
    {0x640000001839C13AULL,0xBE0000001732703AULL},   // HCAL serial #0016 section 1 & 2
    {0x4C0000001736403AULL,0xDF00000017328E3AULL},   // HCAL serial #0017 section 1 & 2
    {0x100000001732843AULL,0x7100000017327A3AULL},   // HCAL serial #0018 section 1 & 2
    {0x0000000000000000ULL,0x0000000000000000ULL},   // reserved for future board #19
    {0x0000000000000000ULL,0x0000000000000000ULL},   // reserved for future board #20
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // reserved for future board #30
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // 
    {0x0000000000000000ULL,0x0000000000000000ULL},   // reserved for future board #40

    {0x9400000007EA803AULL,0x1600000007F6123AULL},   // HCAL "serial #41" (first prototype,shippedd to Oleg) section 1 & 2
    {0xB500000007F6093AULL,0x0D00000007EA753AULL},   // HCAL "serial #42" (2nd prototype, at IU, not fully tested yet)
    {0x9C0000001B4DD23AULL,0x0000000000000000ULL},   // FPS FEE board prototype unit #1, sending to BNL, extensively tested
    {0xE80000001C02173AULL,0x0000000000000000ULL},   // FPS FEE board prototype unit #2 keeping at IU
    {0x550000001C114F3AULL,0x0000000000000000ULL}    // FPS FEE board prototype unit #3 (needs connector still, sending to BNL)
  };
  // This table is the actual measured voltage for a nominal-calibration 68.0000 V output from the board,
  // with compensation slope set to zero.
  // It is assumed therefore that the voltage error is principally just a single gain error, offset error is
  // neglected, and independent gain errors for the common term, setpoint term, and compensation slope term are
  // neglected. These should be very good assumptions, the dominant error source is the 1% sense resistor, which
  // results in a common gain error.
  const double vcal_table[45][2][4]={
    {{67.8449,67.8006,67.7683,67.8616},{67.8476,67.8236,67.7563,67.9094}}, // HCAL #0001
    {{67.9147,67.8009,67.7998,67.8252},{67.8393,67.9067,67.7831,67.9443}}, // HCAL #0002
    {{67.8734,67.8731,67.8923,67.8422},{67.9095,67.8455,67.9292,67.8435}}, // HCAL #0003
    {{67.8795,67.8963,67.8454,67.8412},{67.8345,67.9047,67.9498,67.8416}}, // HCAL #0004
    {{67.9520,67.7886,67.8743,67.8471},{67.8439,67.9318,67.9526,67.8447}}, // HCAL #0005
    {{67.9178,67.8017,67.8730,68.0226},{67.8501,68.0351,67.8590,67.8769}}, // HCAL #0006
    {{67.8477,67.8493,67.8303,67.8179},{67.7987,67.8578,67.8510,67.8309}}, // HCAL #0007
    {{67.9039,67.9156,67.9032,67.9204},{67.9464,67.8700,67.7911,67.8850}}, // HCAL #0008
    {{67.9117,67.9978,67.7427,67.8666},{67.8245,67.7894,67.8940,67.8703}}, // HCAL #0009
    {{67.8990,67.9953,67.8898,67.8420},{67.9474,67.8575,67.8845,67.7855}}, // HCAL #0010
    {{67.8971,67.8732,67.7457,67.9947},{67.8123,67.9421,67.9036,67.8535}}, // HCAL #0011
    {{67.8614,67.8927,67.8674,67.8410},{68.0413,67.8318,67.8966,67.8755}}, // HCAL #0012
    {{67.8710,67.8815,67.8370,67.8791},{67.9053,67.8110,67.7942,67.8684}}, // HCAL #0013
    {{67.8353,67.9973,67.8689,67.8322},{67.9530,67.9159,67.9051,67.8803}}, // HCAL #0014
    {{67.9169,67.8543,67.8303,67.8487},{67.8322,67.7741,67.8973,67.8953}}, // HCAL #0015
    {{67.9232,67.8246,67.9550,67.8905},{67.8690,67.9834,67.8883,67.9564}}, // HCAL #0016
    {{67.9987,67.8534,67.9015,67.9091},{67.8368,67.7776,67.8401,67.9587}}, // HCAL #0017
    {{67.8268,67.9392,67.8358,67.8699},{67.9291,67.8430,67.8632,67.8757}}, // HCAL #0018
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}},
    {{67.7665,67.7882,67.7691,67.7380},{67.8288,67.7961,67.7594,67.9254}}, // 1st prototype "#41"
    {{67.8531,67.9264,67.9139,67.8561},{67.8128,68.0118,67.9073,67.8916}}, // 2nd prototype "#42"
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}}, // FPS FEE board prototype
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}}, // FPS FEE board prototype
    {{68.0000,68.0000,68.0000,68.0000},{68.0000,68.0000,68.0000,68.0000}}  // FPS FEE board prototype
  };
  while((c = getopt(argc, argv, "s:w:b:TNSQ?")) != -1) {
    switch(c) {
    case 'w' : // specify the target 1-wire address   ** DON'T USE THIS OPTION (except maybe for debugging) **
      sscanf(optarg,"%"SCNx64,&owaddr);
      break;
    case 'b' : // specify the board serial number and half (for HCAL) to lookup 1-wire address
      bdhalf=1; // default if not specified, e.g. for EMCAL boards
      sscanf(optarg,"%d:%d",&bdserial,&bdhalf);
      owaddr = owaddr_table[bdserial-1][bdhalf-1];
      break;
    case 's' : // specify a channel:voltage:compensation to set (voltage is specified at 25 deg C)
      sscanf(optarg,"%d:%lf:%lf",&chan,&voltage,&comp);
      do_dac=1;
      break;
    case 'T':
      do_FPS_test_IV=1;
      break;
    case 'N':
      do_standard=1;
      do_standby=0;
      break;
    case 'S':
      do_standby=1;
      do_standard=0;
      break;
    case 'Q':
      do_Iread=1;
      break;
    case '?' :
    default :
      fprintf(stderr,"Usage: %s -b serial:half -s chan:setpoint:compensation -T (do I-V test) -N (set standard operating voltage)"
	      "-S (set standby voltage) -Q (read currents)\n",argv[0]) ;
      return -1;
    }
  }

  if (linkusb_open(&linkusb,0))
    return -1;  // error messages in linkusb_open


  //FPS quick first tests
/*   const uint64_t fps_test_owaddr = owaddr_table[43][0];    // first FPS FEE are 42, 43, 44 here */
  //const uint64_t fps_test_owaddr = 0xCB0000001BFC1F3AULL;  //original board
  const uint64_t fps_test_owaddr = 0x320000001C033F3AULL;
  int testdat;
  //  for(testdat=0;testdat<4095;testdat++) {
/*   for(;;) { */
/*   AD5694_write_dac(&linkusb,0x9C0000001B4DD23AULL,0x0c,0,2440);  // VSET0 */
/*   usleep(100); */
/*   AD5694_write_dac(&linkusb,0x9C0000001B4DD23AULL,0x0c,0,2240);  // VSET0 */
/*   usleep(100); */
/*   } */
  AD5694_write_dac(&linkusb,fps_test_owaddr,0x0c,0,2440);//3574);//2440);  // VSET0
/*   AD5694_write_dac(&linkusb,0x9C0000001B4DD23AULL,0x0c,0,3574);//2440);  // VSET0 */
  AD5694_write_dac(&linkusb,fps_test_owaddr,0x0c,2,0);//2440);//3574);//2440);  // VSET1
  AD5694_write_dac(&linkusb,fps_test_owaddr,0x0c,1,2048);  // VCOMP
  AD5694_write_dac(&linkusb,fps_test_owaddr,0x0c,3,2048);  // VPED
  usleep(500000);
  unsigned int adc;
  //for(;;) {
    ADS7828_convert_read(&linkusb,fps_test_owaddr,0x48,0,&adc);
    printf("ADC 0 read %d: VCOMP=%.3lf V\n",adc,2.500*adc/4096.);
    ADS7828_convert_read(&linkusb,fps_test_owaddr,0x48,2,&adc);
    printf("ADC 2 read %d: SiPM current 0 = %.3lf uA\n",adc,25.*adc/4096.);
    ADS7828_convert_read(&linkusb,fps_test_owaddr,0x48,1,&adc);
    printf("ADC 1 read %d: SiPM current 1 = %.3lf uA\n",adc,25.*adc/4096.);
    //for(;;) {
    ADS7828_convert_read(&linkusb,fps_test_owaddr,0x48,4,&adc);
    printf("ADC 4 read %d: reg 0 control voltage = %.3lf V\n",adc,2.500*adc/4096.);
    //printf("%.4lf ",2.500*adc/4096.);
    ADS7828_convert_read(&linkusb,fps_test_owaddr,0x48,3,&adc);
    printf("ADC 3 read %d: reg 1 control voltage = %.3lf V\n",adc,2.500*adc/4096.);
    //printf("%.4lf\n",2.500*adc/4096.);
    //}
  //printf("wrote %d got %d\n",testdat,adc);
  usleep(500000);
  //}

  linkusb_close(&linkusb);
  return 0;



  if (do_dac) {
    printf("using target 1-wire address %016"PRIx64"\n",owaddr);
    set_voltage(&linkusb,owaddr,chan,vcal_table[bdserial-1][bdhalf-1][chan],&voltage,&comp);
    usleep(300000);
    prototype_get_current(&linkusb,owaddr,&current);
    printf("VI %d %.3lf %.4lf\n",((int) time(NULL))-1400819138,voltage,current);
  }

  if (do_FPS_test_IV) {
    logfile=fopen(IV_LOGFILE,"a");
    fprintf(logfile,"\n\n# time V1 I1 V2 I2  (FPS TEST)\n");  // formatted for gnuplot
    int first=1;
    for(vreq=64.4;vreq<71.8;vreq+=0.1) {
      voltage=vreq;
      voltage_b=vreq;
      comp=0.06;
      comp_b=0.06;
      set_voltage(&linkusb,owaddr_table[42-1][1-1],3,vcal_table[42-1][1-1][3],&voltage,&comp);
      set_voltage(&linkusb,owaddr_table[42-1][2-1],2,vcal_table[42-1][2-1][2],&voltage_b,&comp_b);
      if (first) {
	first=0;
	usleep(2000000); // first point needs a good long delay, since the prior voltage may have been very different
      }
      else
	usleep(100000);  // let voltage & current readout settle a bit
      prototype_get_current(&linkusb,owaddr_table[42-1][1-1],&current);
      fprintf(logfile,"%d %.3lf %.4lf",((int) time(NULL))-1400819138,voltage,current);
      printf("VI: %d %.3lf %.4lf",((int) time(NULL))-1400819138,voltage,current);
      prototype_get_current(&linkusb,owaddr_table[42-1][2-1],&current);
      fprintf(logfile," %.3lf %.4lf\n",voltage_b,current);
      printf(" %.3lf %.4lf\n",voltage_b,current);
    }
    fclose(logfile);
    if (!do_standby) {  // always set normal voltage after scan finished, UNLESS called to set standy
      do_standard=1;
      printf("scan done, restoring normal operating point\n");
    }
  }

  if (do_standard) {
    voltage=66.91;    // Hamamatsu recommended value for this device (serial # 888, 50um)
    voltage_b=68.03;  // Hamamatsu recommended value for this device (serial # 943, 25um)
    comp=0.06;
    comp_b=0.06;
    set_voltage(&linkusb,owaddr_table[42-1][1-1],3,vcal_table[42-1][1-1][3],&voltage,&comp);
    set_voltage(&linkusb,owaddr_table[42-1][2-1],2,vcal_table[42-1][2-1][2],&voltage_b,&comp_b);
    usleep(2000000);
    prototype_get_current(&linkusb,owaddr_table[42-1][1-1],&current);
    printf("VI: %d %.3lf %.4lf",((int) time(NULL))-1400819138,voltage,current);
    prototype_get_current(&linkusb,owaddr_table[42-1][2-1],&current);
    printf(" %.3lf %.4lf\n",voltage_b,current);
  }

  if (do_standby) {
    voltage=55.0;
    voltage_b=55.0;
    comp=0.0;
    comp_b=0.0;
    set_voltage(&linkusb,owaddr_table[42-1][1-1],3,vcal_table[42-1][1-1][3],&voltage,&comp);
    set_voltage(&linkusb,owaddr_table[42-1][2-1],2,vcal_table[42-1][2-1][2],&voltage_b,&comp_b);
    usleep(2000000);
    prototype_get_current(&linkusb,owaddr_table[42-1][1-1],&current);
    printf("VI: %d %.3lf %.4lf",((int) time(NULL))-1400819138,voltage,current);
    prototype_get_current(&linkusb,owaddr_table[42-1][2-1],&current);
    printf(" %.3lf %.4lf\n",voltage_b,current);
  }

  if (do_Iread) {
    prototype_get_current(&linkusb,owaddr_table[42-1][1-1],&current);
    printf("at time %d s, FPS test box SiPM currents are %.4lf uA,",((int) time(NULL))-1400819138,current);
    prototype_get_current(&linkusb,owaddr_table[42-1][2-1],&current);
    printf(" %.4lf uA\n",current);
  }

  linkusb_close(&linkusb);
  return 0;
}
